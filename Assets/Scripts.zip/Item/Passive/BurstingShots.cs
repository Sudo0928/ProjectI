using UnityEngine;

public class BurstingShots : SpecialAbility
{
    private BaseTear tear;

    private void OnEnable()
    {
        //EventManager.RegisterListener<TearDestroyEvent>(Division, 1);
    }

    private void OnDisable()
    {
        //EventManager.UnregisterListener<TearDestroyEvent>(Division);
    }
     
    private void Division(TearDropEvent e)
    {
        this.tear = e.tear;

        Division();
    }

    private void Division(TearHitObstacleEvent e)
    {
        this.tear = e.tear;

        if (this.tear.Size < 0.5f) return;

        if (e.hitCollision.contactCount > 0)
        {
            Vector2 normal = e.hitCollision.contacts[0].normal;

            for (int i = 0; i < 4; i++)
            {
                float randomX = 0;
                float randomY = 0;

                randomX = randomX.GetRange(-1f, 1f);
                randomY = randomX.GetRange(-1f, 1f);

                randomX = normal.x != 0 ? normal.x * 0.5f : randomX;
                randomY = normal.y != 0 ? normal.y * 0.5f : randomY;


                Vector2 direction = new Vector2(randomX, randomY).normalized;

                Debug.Log(direction);

                BaseTear temptear = tear;

                temptear = Instantiate(temptear);
                temptear.Init(tear.Owner, tear.Speed, tear.Distance * 0.5f, tear.Size * 0.5f, direction, tear.IsParbolic);
            }
        }
    }

    private void Division()
    {
        if (this.tear.Size < 0.9f) return;

        BaseTear temptear = tear;

        float randomX = Random.Range(0f, 1f);
        float randomY = Random.Range(0f, 1f);

        temptear = Instantiate(temptear);
        temptear.Init(tear.Owner, tear.Speed, tear.Distance, tear.Size * 0.5f, new Vector2(randomX, randomY), tear.IsParbolic);

        randomX = Random.Range(0f, 1f);
        randomY = Random.Range(0f, 1f);

        temptear = Instantiate(tear);
        temptear.Init(tear.Owner, tear.Speed, tear.Distance, tear.Size * 0.5f, new Vector2(-randomX, randomY), tear.IsParbolic);

        randomX = Random.Range(0f, 1f);
        randomY = Random.Range(0f, 1f);

        temptear = Instantiate(tear);
        temptear.Init(tear.Owner, tear.Speed, tear.Distance, tear.Size * 0.5f, new Vector2(randomX, -randomY), tear.IsParbolic);

        randomX = Random.Range(0f, 1f);
        randomY = Random.Range(0f, 1f);

        temptear = Instantiate(tear);
        temptear.Init(tear.Owner, tear.Speed, tear.Distance, tear.Size * 0.5f, new Vector2(-randomX, -randomY), tear.IsParbolic);
    }

    public override void OnAbility(Player player)
	{
		EventManager.RegisterListener<TearDropEvent>(Division, 1);
		EventManager.RegisterListener<TearHitObstacleEvent>(Division, 1);
	}

	public override void RemoveSkill()
	{
		EventManager.UnregisterListener<TearDropEvent>(Division);
		EventManager.UnregisterListener<TearHitObstacleEvent>(Division);
	}
}